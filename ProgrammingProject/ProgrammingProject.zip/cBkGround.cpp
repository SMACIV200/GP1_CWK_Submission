/*
=================
cRocket.cpp
- Header file for class definition - IMPLEMENTATION
=================
*/
#include "cBkGround.h"

void cBkGround::render()
{
	cSprite::render();
}
/*
=================================================================
Update the sprite position
=================================================================
*/

void cBkGround::update(float deltaTime)
{
}
