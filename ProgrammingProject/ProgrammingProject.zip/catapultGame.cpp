/*
==================================================================================
asteroidsGame.cpp
==================================================================================
*/

#include "catapultGame.h"

vector<cTexture*> theGameTextures;
vector<cTarget*> theTargets;
vector<cRock*> theRocks;
